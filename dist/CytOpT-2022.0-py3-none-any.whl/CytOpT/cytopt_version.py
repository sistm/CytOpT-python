"""
__version__.py
Information about the current version of the package.
"""

__title__ = 'CytOpT'
__version__ = '2022.0'
__author__ = ['Paul Freulon', 'Kalidou BA', 'Boris Hejblum']
__author_email__ = 'paul.freulon@math.u-bordeaux.fr'
__license__ = 'MIT'