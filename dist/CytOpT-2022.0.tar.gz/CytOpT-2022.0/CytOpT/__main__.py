from CytOpT import main

main.main()
