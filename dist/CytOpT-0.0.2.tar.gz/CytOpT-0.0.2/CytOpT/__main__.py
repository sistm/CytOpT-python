
if __name__ == "__main__":
    from CytOpT import main
    main.main()